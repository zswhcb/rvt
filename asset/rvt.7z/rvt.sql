/*
Navicat MySQL Data Transfer

Source Server         : hq-mysql-1:22306
Source Server Version : 50623
Source Host           : 127.0.0.1:22306
Source Database       : rvt

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2015-12-07 16:07:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `p_handtask`
-- ----------------------------
DROP TABLE IF EXISTS `p_handtask`;
CREATE TABLE `p_handtask` (
  `id` varchar(32) NOT NULL,
  `TALK_TIME` datetime DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL,
  `TASK_ID` varchar(32) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_handtask
-- ----------------------------

-- ----------------------------
-- Table structure for `p_project`
-- ----------------------------
DROP TABLE IF EXISTS `p_project`;
CREATE TABLE `p_project` (
  `id` varchar(32) NOT NULL,
  `PROJECT_NAME` varchar(32) DEFAULT NULL,
  `PROJECT_INTRO` varchar(512) DEFAULT NULL,
  `PROJECT_TYPE` varchar(32) DEFAULT NULL,
  `TEL_NUM` varchar(128) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project
-- ----------------------------

-- ----------------------------
-- Table structure for `p_project_type`
-- ----------------------------
DROP TABLE IF EXISTS `p_project_type`;
CREATE TABLE `p_project_type` (
  `id` varchar(32) NOT NULL,
  `TYPE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project_type
-- ----------------------------

-- ----------------------------
-- Table structure for `p_task`
-- ----------------------------
DROP TABLE IF EXISTS `p_task`;
CREATE TABLE `p_task` (
  `id` varchar(32) NOT NULL,
  `TASK_NAME` varchar(32) DEFAULT NULL,
  `TASK_INTRO` varchar(512) DEFAULT NULL,
  `TASK_SUM` int(11) DEFAULT NULL,
  `PROJECT_ID` varchar(32) DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL COMMENT '有效通话时长',
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_task
-- ----------------------------

-- ----------------------------
-- Table structure for `s_auth_code`
-- ----------------------------
DROP TABLE IF EXISTS `s_auth_code`;
CREATE TABLE `s_auth_code` (
  `id` varchar(32) NOT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_auth_code
-- ----------------------------

-- ----------------------------
-- Table structure for `s_role`
-- ----------------------------
DROP TABLE IF EXISTS `s_role`;
CREATE TABLE `s_role` (
  `id` varchar(32) NOT NULL,
  `ROLE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_role
-- ----------------------------
INSERT INTO `s_role` VALUES ('566512760fd5504c45483a93', '超级管理员', '2015-12-01 15:57:22', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace4', '管理员', '2015-12-02 15:57:27', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace5', '信息发布者', '2015-12-03 15:57:31', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace6', '业务员', '2015-12-04 15:57:36', '1');

-- ----------------------------
-- Table structure for `s_user`
-- ----------------------------
DROP TABLE IF EXISTS `s_user`;
CREATE TABLE `s_user` (
  `id` varchar(32) NOT NULL,
  `USER_NAME` varchar(32) DEFAULT NULL,
  `USER_PASS` varchar(32) DEFAULT NULL,
  `AVATAR_URL` varchar(128) DEFAULT NULL,
  `EMAIL` varchar(64) DEFAULT NULL,
  `MOBILE` varchar(11) DEFAULT NULL,
  `REAL_NAME` varchar(32) DEFAULT NULL,
  `ALIPAY_ACCOUNT` varchar(128) DEFAULT NULL,
  `APIKEY` varchar(64) DEFAULT NULL,
  `SECKEY` varchar(64) DEFAULT NULL,
  `AUTH_CODE_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_user
-- ----------------------------
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a91', 'hx', 'e10adc3949ba59abbe56e057f20f883e', '', '3203317@qq.com', '13837186852', null, null, null, null, null, '2015-09-30 16:33:09', '1');
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a92', 'wp', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null, null, null, null, null, '2015-09-30 16:33:09', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd32', 'admin', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null, null, null, null, null, '2015-12-07 13:05:02', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd33', 'hq', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null, null, null, null, null, '2015-12-07 13:05:42', '1');

-- ----------------------------
-- Table structure for `s_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `s_user_role`;
CREATE TABLE `s_user_role` (
  `USER_ID` varchar(32) DEFAULT NULL,
  `ROLE_ID` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_user_role
-- ----------------------------
INSERT INTO `s_user_role` VALUES ('5665135f0447a8f04668fd32', '566512760fd5504c45483a93');
INSERT INTO `s_user_role` VALUES ('566512760fd5504c45483a92', '566512b49012fb044691ace4');
INSERT INTO `s_user_role` VALUES ('5665135f0447a8f04668fd33', '566512b49012fb044691ace4');
INSERT INTO `s_user_role` VALUES ('566512760fd5504c45483a91', '566512b49012fb044691ace5');
