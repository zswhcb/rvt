/*
Navicat MySQL Data Transfer

Source Server         : hq-mysql-1:22306
Source Server Version : 50623
Source Host           : 127.0.0.1:22306
Source Database       : rvt

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2015-12-16 14:26:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `_s_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `_s_user_role`;
CREATE TABLE `_s_user_role` (
  `USER_ID` varchar(32) NOT NULL DEFAULT '',
  `ROLE_ID` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`USER_ID`,`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of _s_user_role
-- ----------------------------
INSERT INTO `_s_user_role` VALUES ('566512760fd5504c45483a91', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('566512760fd5504c45483a92', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('5665135f0447a8f04668fd32', '566512760fd5504c45483a93');
INSERT INTO `_s_user_role` VALUES ('5665135f0447a8f04668fd33', '566512b49012fb044691ace5');
INSERT INTO `_s_user_role` VALUES ('56654ccbbace76fc6d67073e', '566512b49012fb044691ace5');
INSERT INTO `_s_user_role` VALUES ('56666155089a64dc10881fd6', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('5666d061cca60fe0113d1391', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('5666d0c7cca60fe0113d1392', '566512b49012fb044691ace6');

-- ----------------------------
-- Table structure for `p_handtask`
-- ----------------------------
DROP TABLE IF EXISTS `p_handtask`;
CREATE TABLE `p_handtask` (
  `id` varchar(32) NOT NULL,
  `TEL_NUM` varchar(16) DEFAULT NULL,
  `UPLOAD_TIME` datetime DEFAULT NULL,
  `TALK_TIME` datetime DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL,
  `TASK_ID` varchar(32) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_handtask
-- ----------------------------
INSERT INTO `p_handtask` VALUES ('1', '13683800587', '2015-12-15 23:57:19', '2015-12-09 10:44:12', '31', '566774f58c831de01597a043', '566512760fd5504c45483a91', '2015-12-10 10:44:30', '1');
INSERT INTO `p_handtask` VALUES ('2', null, null, '2015-12-17 11:03:54', '33', '566774f58c831de01597a043', '566512760fd5504c45483a91', '2015-12-11 11:04:08', '2');
INSERT INTO `p_handtask` VALUES ('3', null, null, '2015-12-17 11:03:54', '40', '566774f58c831de01597a043', '566512760fd5504c45483a91', '2015-12-12 16:04:08', '0');
INSERT INTO `p_handtask` VALUES ('4', null, null, null, null, '566774f58c831de01597a043', '566512760fd5504c45483a91', '2015-12-16 13:33:57', '1');

-- ----------------------------
-- Table structure for `p_project`
-- ----------------------------
DROP TABLE IF EXISTS `p_project`;
CREATE TABLE `p_project` (
  `id` varchar(32) NOT NULL,
  `PROJECT_NAME` varchar(32) DEFAULT NULL,
  `PROJECT_INTRO` varchar(512) DEFAULT NULL,
  `PROJECT_TYPE_ID` varchar(32) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project
-- ----------------------------
INSERT INTO `p_project` VALUES ('56654bf2709f27ec7219d7ef', 'A项目一期201503', '中国9·3大阅兵体现了战略弹道导弹、巡航导弹武器遏制力量的最新变化。这才是最需要重视的。阅兵式上东风-15B、东风-16、东风-21D、东风-26、东风-31A、东风-5B依次亮相,涵盖600千米至12000千米射程,具体体现了五重战略威慑、遏制力量的排列。', '56654bf2709f27ec7219d7ee', '5665135f0447a8f04668fd33', '2015-12-07 17:06:53', '1');
INSERT INTO `p_project` VALUES ('566576f22fa833b4064e3fe3', 'B项目一期201505', '其次采用核潜艇、无人机、岸基侦察机、预警机对航行中的美航母舰队实施精确定位、跟踪,不断传回数据,东风-21D根据这些坐标,实施打击。这需要中国的各种探测平台前出到接近第一岛链的海空领域。', '56654bf2709f27ec7219d7ee', '56654ccbbace76fc6d67073e', '2015-12-07 20:10:11', '1');
INSERT INTO `p_project` VALUES ('5666af69fabc04001f1f9f24', 'B项目一期201504', '驾驶证、身份证都有有效期，为什么结婚证不能有有效期？面对难以抵挡的第四次单身潮和现在与日俱增的离婚率，近日，某学者提出一种大胆而令人惊叹的声音：结婚证应设置7年有效期，到期自动离婚，这样一来，许多社会问题就会迎刃而解。', '56654bf2709f27ec7219d7ee', '56654ccbbace76fc6d67073e', '2015-12-08 18:22:34', '1');
INSERT INTO `p_project` VALUES ('5666af73fabc04001f1f9f25', 'A项目一期201502', '大国的核威慑、核/常遏制层次是多重的,这一点具体体现在冷战时代美苏五重核遏制体系。五重遏制是相辅相成的,缺一不可,最高层次的遏制,当然是对对方首都、核基地实施的洲际弹道导弹打击。', '56654bf2709f27ec7219d7ee', '5665135f0447a8f04668fd33', '2015-12-08 18:22:44', '1');
INSERT INTO `p_project` VALUES ('5667d2c33c848ea00185cdcf', 'B项目一期201503', '到了这一层次,中美直接较量将难以避免,因此,中国对美第三层次的遏制,是使用新型的东风-21D打击航母舰队。这一层次,包括2种打击方式,第一种是打击港湾内的航母,主要针对日本横须贺基地的美军“里根”号核动力航母,依照目前二炮弹道导弹的打击精度,采用中段“北斗”、末段雷达成像技术制导,直接命中港湾静止状态的航母是可行的。', '56654bf2709f27ec7219d7ee', '56654ccbbace76fc6d67073e', '2015-12-09 15:05:40', '1');
INSERT INTO `p_project` VALUES ('5667d2d43c848ea00185cdd0', 'B项目一期201502', '东风-16的弹头也可以看出锥形结构,弹道导弹对冲绳的打击,首轮攻击也有可能是对指挥大楼、战略中心的袭击,因此需要安装延迟引信,穿透大楼,这是几次冷战后局部战争的经验,美军的巡航导弹、GPS制导炸弹在首轮攻击中,尤其是对政府、军事机关的攻击,都采用延迟引信,实现穿地。当然东风-16可以携带的弹种也应该是多样的,基本上可能与东风-15相同。', '56654bf2709f27ec7219d7ee', '56654ccbbace76fc6d67073e', '2015-12-09 15:05:56', '1');
INSERT INTO `p_project` VALUES ('5667e62cdfe75acc1514ba51', 'A项目一期201501', '能聊天的美女情感机器人来了!能打乒乓球的机器人可以和你对打!一群机器人在小场地里踢足球……2015世界机器人大会如同“武林大会”,各路厂商带着“小宝贝”纷纷亮相,世界机器人领域大师级的专家学者纷纷登台指点“现在与未来”的智能世界。', '56654bf2709f27ec7219d7ee', '5665135f0447a8f04668fd33', '2015-12-09 16:28:29', '1');
INSERT INTO `p_project` VALUES ('566ec9d9a945957c0eee6b21', 'B项目一期201501', '首先看东风-15B短程导弹,一切遏制的起点从此开始,当然是针对台湾、南中国海、东中国海上的纷争地区,主要是台湾,这种导弹涵盖了整个台湾海峡和台湾岛。', '5667e4416c6a323c194f97f2', '56654ccbbace76fc6d67073e', '2015-12-14 21:53:30', '1');

-- ----------------------------
-- Table structure for `p_project_type`
-- ----------------------------
DROP TABLE IF EXISTS `p_project_type`;
CREATE TABLE `p_project_type` (
  `id` varchar(32) NOT NULL,
  `TYPE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project_type
-- ----------------------------
INSERT INTO `p_project_type` VALUES ('56654bf2709f27ec7219d7ee', '房地产', '2015-12-07 17:06:25', '1');
INSERT INTO `p_project_type` VALUES ('5667e4416c6a323c194f97f2', '其他', '2015-12-09 16:18:02', '1');

-- ----------------------------
-- Table structure for `p_task`
-- ----------------------------
DROP TABLE IF EXISTS `p_task`;
CREATE TABLE `p_task` (
  `id` varchar(32) NOT NULL,
  `TEL_NUM` varchar(255) DEFAULT NULL,
  `TASK_NAME` varchar(32) DEFAULT NULL,
  `TASK_INTRO` varchar(512) DEFAULT NULL,
  `TASK_SUM` int(11) DEFAULT NULL,
  `PROJECT_ID` varchar(32) DEFAULT NULL,
  `TALK_TIMEOUT` int(11) DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL COMMENT '有效通话时长',
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_task
-- ----------------------------
INSERT INTO `p_task` VALUES ('566774f58c831de01597a043', '13837186852', '002--04--02', '任务描述1', '30', '5666af69fabc04001f1f9f24', '3600', '40', '2015-12-10 08:25:17', '2015-12-18 08:25:17', '2015-12-09 08:25:25', '1');
INSERT INTO `p_task` VALUES ('566786ddca5012040d6d31a5', '13837186852', '002--04--01', '任务描述2', '20', '5666af69fabc04001f1f9f24', '3600', '30', '2015-12-01 09:41:22', '2015-12-02 09:41:26', '2015-12-09 09:41:49', '2');
INSERT INTO `p_task` VALUES ('5667d2fc3c848ea00185cdd1', '18530053050', '002--04--04', '6', '20', '5666af69fabc04001f1f9f24', '3600', '30', '2015-12-16 15:06:31', '2015-12-17 15:06:31', '2015-12-09 15:06:37', '1');
INSERT INTO `p_task` VALUES ('566a29941007c8380a50e345', '13837186852', '001--01--01', '任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介', '20', '5667e62cdfe75acc1514ba51', '3600', '30', '2015-12-15 09:40:30', '2015-12-16 22:25:10', '2015-12-11 09:40:37', '1');
INSERT INTO `p_task` VALUES ('566bd3418fa7fba0182853b5', '13837186852', '001--01--02', '任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介', '30', '5667e62cdfe75acc1514ba51', '3600', '30', '2015-12-15 15:56:44', '2015-12-16 15:56:45', '2015-12-12 15:56:49', '1');
INSERT INTO `p_task` VALUES ('566f86164edd83a4045ee105', '18530053050', '002--01--01', '任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介', '40', '566ec9d9a945957c0eee6b21', '3600', '40', '2015-12-15 22:28:08', '2015-12-16 22:28:12', '2015-12-15 11:16:38', '1');
INSERT INTO `p_task` VALUES ('5670218baf29a49416e6c1f3', '18530053050', '002--04--03', '任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介任务简介', '40', '5666af69fabc04001f1f9f24', '3600', '40', '2015-12-16 22:19:37', '2015-12-17 22:19:37', '2015-12-15 22:19:56', '1');

-- ----------------------------
-- Table structure for `s_auth_code`
-- ----------------------------
DROP TABLE IF EXISTS `s_auth_code`;
CREATE TABLE `s_auth_code` (
  `id` varchar(32) NOT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_auth_code
-- ----------------------------
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550457', '566512760fd5504c45483a91', '2015-12-08 15:20:16', '1');
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550458', '566512760fd5504c45483a91', '2015-12-08 15:47:03', '1');
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550459', '566512760fd5504c45483a92', '2015-12-08 15:47:06', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28a', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28b', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28c', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28d', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28e', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28f', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f290', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f291', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f292', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f293', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c44', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c45', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c46', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c47', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c48', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c49', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4a', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4b', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4c', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4d', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c4e', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c4f', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c50', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c51', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c52', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c53', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c54', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c55', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c56', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c57', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7051', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7052', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7053', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7054', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7055', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7056', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7057', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7058', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7059', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d705a', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd4', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd5', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd6', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd7', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd8', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd9', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecda', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdb', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdc', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdd', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999277', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999278', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999279', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927a', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927b', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927c', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927d', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927e', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927f', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999280', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999281', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999282', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999283', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999284', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999285', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999286', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999287', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999288', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999289', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c1399928a', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc1', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc2', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc3', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc4', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc5', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc6', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc7', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc8', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc9', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edca', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d3', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d4', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d5', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d6', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d7', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d8', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d9', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7da', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7db', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7dc', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8c', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8d', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8e', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8f', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc90', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc91', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc92', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc93', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc94', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc95', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c87', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c88', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c89', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8a', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8b', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8c', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8d', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8e', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8f', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c90', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe656', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe657', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe658', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe659', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65a', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65b', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65c', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65d', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65e', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65f', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');

-- ----------------------------
-- Table structure for `s_role`
-- ----------------------------
DROP TABLE IF EXISTS `s_role`;
CREATE TABLE `s_role` (
  `id` varchar(32) NOT NULL,
  `ROLE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_role
-- ----------------------------
INSERT INTO `s_role` VALUES ('566512760fd5504c45483a93', '超级管理员', '2015-12-01 15:57:22', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace4', '管理员', '2015-12-02 15:57:27', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace5', '信息发布者', '2015-12-03 15:57:31', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace6', '业务员', '2015-12-04 15:57:36', '1');

-- ----------------------------
-- Table structure for `s_user`
-- ----------------------------
DROP TABLE IF EXISTS `s_user`;
CREATE TABLE `s_user` (
  `id` varchar(32) NOT NULL,
  `ROLE_ID` varchar(32) DEFAULT NULL,
  `USER_NAME` varchar(32) DEFAULT NULL,
  `USER_PASS` varchar(32) DEFAULT NULL,
  `AVATAR_URL` varchar(128) DEFAULT NULL,
  `EMAIL` varchar(64) DEFAULT NULL,
  `MOBILE` varchar(11) DEFAULT NULL,
  `REAL_NAME` varchar(32) DEFAULT NULL,
  `ALIPAY_ACCOUNT` varchar(128) DEFAULT NULL,
  `APIKEY` varchar(64) DEFAULT NULL,
  `SECKEY` varchar(64) DEFAULT NULL,
  `AUTH_CODE_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_user
-- ----------------------------
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a91', '566512b49012fb044691ace6', '18530053050', 'e10adc3949ba59abbe56e057f20f883e', '', '3203317@qq.com', '18530053050', '黄鑫', '3203317@qq.com', '123', '234', '', '2015-09-30 16:33:09', '1');
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a92', '566512b49012fb044691ace6', '13838394480', 'e10adc3949ba59abbe56e057f20f883e', null, '13838394480@qq.com', '13838394480', '吴鹏', '13838394480@qq.com', null, null, '', '2015-09-30 17:33:09', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd32', '566512760fd5504c45483a93', 'bushuo', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '超级管理员', '', null, null, '', '2015-12-07 13:05:02', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd33', '566512b49012fb044691ace5', 'xxfb001', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '信息发布者001', '', null, null, '', '2015-12-07 13:05:42', '1');
INSERT INTO `s_user` VALUES ('56654ccbbace76fc6d67073e', '566512b49012fb044691ace5', 'xxfb002', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '信息发布者002', '', null, null, '', '2015-12-07 17:10:24', '1');
INSERT INTO `s_user` VALUES ('56666155089a64dc10881fd6', '566512b49012fb044691ace6', '13683800587', 'e10adc3949ba59abbe56e057f20f883e', null, '13683800587@139.com', '13683800587', '假名', '13683800587@139.com', '', '', '5666880a1ac2f8840e550457', '2015-12-08 12:49:26', '1');
INSERT INTO `s_user` VALUES ('5666d061cca60fe0113d1391', '566512b49012fb044691ace6', '13526667995', 'e10adc3949ba59abbe56e057f20f883e', null, '13526667995@qq.com', '13526667995', '郝全', '13526667995@qq.com', '', '', '', '2015-12-08 20:43:13', '1');
INSERT INTO `s_user` VALUES ('5666d0c7cca60fe0113d1392', '566512b49012fb044691ace6', '13137708990', 'e10adc3949ba59abbe56e057f20f883e', null, '13137708990@139.com', '13137708990', '杨光', '13137708990@139.com', '', '', '', '2015-12-08 20:44:56', '1');
