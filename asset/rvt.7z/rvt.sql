/*
Navicat MySQL Data Transfer

Source Server         : hq-mysql-1:22306
Source Server Version : 50623
Source Host           : 127.0.0.1:22306
Source Database       : rvt

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2015-12-08 21:18:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `p_handtask`
-- ----------------------------
DROP TABLE IF EXISTS `p_handtask`;
CREATE TABLE `p_handtask` (
  `id` varchar(32) NOT NULL,
  `TALK_TIME` datetime DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL,
  `TASK_ID` varchar(32) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_handtask
-- ----------------------------

-- ----------------------------
-- Table structure for `p_project`
-- ----------------------------
DROP TABLE IF EXISTS `p_project`;
CREATE TABLE `p_project` (
  `id` varchar(32) NOT NULL,
  `PROJECT_NAME` varchar(32) DEFAULT NULL,
  `PROJECT_INTRO` varchar(512) DEFAULT NULL,
  `PROJECT_TYPE_ID` varchar(32) DEFAULT NULL,
  `TEL_NUM` varchar(128) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project
-- ----------------------------
INSERT INTO `p_project` VALUES ('56654bf2709f27ec7219d7ef', '项目项目项目项目一', '项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介', '56654bf2709f27ec7219d7ee', '13837186852,18530053050', '5665135f0447a8f04668fd33', '2015-12-07 17:06:53', '1');
INSERT INTO `p_project` VALUES ('566576f22fa833b4064e3fe3', '项目项目项目项目二', null, '56654bf2709f27ec7219d7ee', '13837186852', '56654ccbbace76fc6d67073e', '2015-12-07 20:10:11', '2');
INSERT INTO `p_project` VALUES ('5666af69fabc04001f1f9f24', '1', '3', '56654bf2709f27ec7219d7ee', '2', '56654ccbbace76fc6d67073e', '2015-12-08 18:22:34', '1');
INSERT INTO `p_project` VALUES ('5666af73fabc04001f1f9f25', '3', '5555', '56654bf2709f27ec7219d7ee', '4444', '5665135f0447a8f04668fd33', '2015-12-08 18:22:44', '1');

-- ----------------------------
-- Table structure for `p_project_type`
-- ----------------------------
DROP TABLE IF EXISTS `p_project_type`;
CREATE TABLE `p_project_type` (
  `id` varchar(32) NOT NULL,
  `TYPE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project_type
-- ----------------------------
INSERT INTO `p_project_type` VALUES ('56654bf2709f27ec7219d7ee', '房地产', '2015-12-07 17:06:25', '1');

-- ----------------------------
-- Table structure for `p_task`
-- ----------------------------
DROP TABLE IF EXISTS `p_task`;
CREATE TABLE `p_task` (
  `id` varchar(32) NOT NULL,
  `TASK_NAME` varchar(32) DEFAULT NULL,
  `TASK_INTRO` varchar(512) DEFAULT NULL,
  `TASK_SUM` int(11) DEFAULT NULL,
  `PROJECT_ID` varchar(32) DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL COMMENT '有效通话时长',
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_task
-- ----------------------------

-- ----------------------------
-- Table structure for `s_auth_code`
-- ----------------------------
DROP TABLE IF EXISTS `s_auth_code`;
CREATE TABLE `s_auth_code` (
  `id` varchar(32) NOT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_auth_code
-- ----------------------------
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550457', '566512760fd5504c45483a91', '2015-12-08 15:20:16', '1');
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550458', '566512760fd5504c45483a91', '2015-12-08 15:47:03', '1');
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550459', '566512760fd5504c45483a92', '2015-12-08 15:47:06', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28a', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28b', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28c', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28d', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28e', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28f', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f290', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f291', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f292', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f293', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c44', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c45', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c46', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c47', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c48', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c49', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4a', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4b', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4c', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4d', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c4e', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c4f', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c50', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c51', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c52', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c53', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c54', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c55', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c56', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c57', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7051', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7052', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7053', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7054', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7055', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7056', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7057', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7058', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7059', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d705a', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd4', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd5', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd6', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd7', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd8', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd9', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecda', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdb', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdc', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdd', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');

-- ----------------------------
-- Table structure for `s_role`
-- ----------------------------
DROP TABLE IF EXISTS `s_role`;
CREATE TABLE `s_role` (
  `id` varchar(32) NOT NULL,
  `ROLE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_role
-- ----------------------------
INSERT INTO `s_role` VALUES ('566512760fd5504c45483a93', '超级管理员', '2015-12-01 15:57:22', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace4', '管理员', '2015-12-02 15:57:27', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace5', '信息发布者', '2015-12-03 15:57:31', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace6', '业务员', '2015-12-04 15:57:36', '1');

-- ----------------------------
-- Table structure for `s_user`
-- ----------------------------
DROP TABLE IF EXISTS `s_user`;
CREATE TABLE `s_user` (
  `id` varchar(32) NOT NULL,
  `USER_NAME` varchar(32) DEFAULT NULL,
  `USER_PASS` varchar(32) DEFAULT NULL,
  `AVATAR_URL` varchar(128) DEFAULT NULL,
  `EMAIL` varchar(64) DEFAULT NULL,
  `MOBILE` varchar(11) DEFAULT NULL,
  `REAL_NAME` varchar(32) DEFAULT NULL,
  `ALIPAY_ACCOUNT` varchar(128) DEFAULT NULL,
  `APIKEY` varchar(64) DEFAULT NULL,
  `SECKEY` varchar(64) DEFAULT NULL,
  `AUTH_CODE_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_user
-- ----------------------------
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a91', 'hx', 'e10adc3949ba59abbe56e057f20f883e', '', '3203317@qq.com', '18530053050', '黄鑫', '3203317@qq.com', '1', '2', '', '2015-09-30 16:33:09', '1');
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a92', 'wp', 'e10adc3949ba59abbe56e057f20f883e', null, 'null', 'null', '吴鹏', 'null', null, null, '', '2015-09-30 16:33:09', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd32', 'admin', 'e10adc3949ba59abbe56e057f20f883e', null, null, null, null, null, null, null, '', '2015-12-07 13:05:02', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd33', 'xxfb001', 'e10adc3949ba59abbe56e057f20f883e', null, 'null', 'null', '信息发布者001', 'null', null, null, '', '2015-12-07 13:05:42', '1');
INSERT INTO `s_user` VALUES ('56654ccbbace76fc6d67073e', 'xxfb002', 'e10adc3949ba59abbe56e057f20f883e', null, 'null', 'null', '信息发布者002', 'null', null, null, '', '2015-12-07 17:10:24', '1');
INSERT INTO `s_user` VALUES ('56666155089a64dc10881fd6', 'wy', 'e10adc3949ba59abbe56e057f20f883e', null, '3203317@qq.com', '13683800587', '假名', '3203317@qq.com', '', '', '5666880a1ac2f8840e550457', '2015-12-08 12:49:26', '1');
INSERT INTO `s_user` VALUES ('5666676605350ad41480bd2e', 'test002', 'e10adc3949ba59abbe56e057f20f883e', null, 'asdfadfasdf', '', '', '', '', '', '5666880a1ac2f8840e550458', '2015-12-08 13:15:18', '1');
INSERT INTO `s_user` VALUES ('5666676c05350ad41480bd2f', 'test003', 'e10adc3949ba59abbe56e057f20f883e', null, '1', '2', '3', '4', '', '', '5666880a1ac2f8840e550459', '2015-12-08 13:15:24', '1');
INSERT INTO `s_user` VALUES ('5666d061cca60fe0113d1391', 'hq', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '郝全', '', '', '', '', '2015-12-08 20:43:13', '1');
INSERT INTO `s_user` VALUES ('5666d0c7cca60fe0113d1392', 'yg', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '杨光', '', '', '', '', '2015-12-08 20:44:56', '1');

-- ----------------------------
-- Table structure for `s_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `s_user_role`;
CREATE TABLE `s_user_role` (
  `USER_ID` varchar(32) NOT NULL DEFAULT '',
  `ROLE_ID` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`USER_ID`,`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_user_role
-- ----------------------------
INSERT INTO `s_user_role` VALUES ('566512760fd5504c45483a91', '566512b49012fb044691ace6');
INSERT INTO `s_user_role` VALUES ('566512760fd5504c45483a92', '566512b49012fb044691ace6');
INSERT INTO `s_user_role` VALUES ('5665135f0447a8f04668fd32', '566512760fd5504c45483a93');
INSERT INTO `s_user_role` VALUES ('5665135f0447a8f04668fd33', '566512b49012fb044691ace5');
INSERT INTO `s_user_role` VALUES ('56654ccbbace76fc6d67073e', '566512b49012fb044691ace5');
INSERT INTO `s_user_role` VALUES ('56666155089a64dc10881fd6', '566512b49012fb044691ace6');
INSERT INTO `s_user_role` VALUES ('5666d061cca60fe0113d1391', '566512b49012fb044691ace6');
INSERT INTO `s_user_role` VALUES ('5666d0c7cca60fe0113d1392', '566512b49012fb044691ace6');
