/*
Navicat MySQL Data Transfer

Source Server         : hq-mysql-1:22306
Source Server Version : 50623
Source Host           : 127.0.0.1:22306
Source Database       : rvt

Target Server Type    : MYSQL
Target Server Version : 50623
File Encoding         : 65001

Date: 2015-12-15 15:00:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `_s_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `_s_user_role`;
CREATE TABLE `_s_user_role` (
  `USER_ID` varchar(32) NOT NULL DEFAULT '',
  `ROLE_ID` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`USER_ID`,`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of _s_user_role
-- ----------------------------
INSERT INTO `_s_user_role` VALUES ('566512760fd5504c45483a91', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('566512760fd5504c45483a92', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('5665135f0447a8f04668fd32', '566512760fd5504c45483a93');
INSERT INTO `_s_user_role` VALUES ('5665135f0447a8f04668fd33', '566512b49012fb044691ace5');
INSERT INTO `_s_user_role` VALUES ('56654ccbbace76fc6d67073e', '566512b49012fb044691ace5');
INSERT INTO `_s_user_role` VALUES ('56666155089a64dc10881fd6', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('5666d061cca60fe0113d1391', '566512b49012fb044691ace6');
INSERT INTO `_s_user_role` VALUES ('5666d0c7cca60fe0113d1392', '566512b49012fb044691ace6');

-- ----------------------------
-- Table structure for `p_handtask`
-- ----------------------------
DROP TABLE IF EXISTS `p_handtask`;
CREATE TABLE `p_handtask` (
  `id` varchar(32) NOT NULL,
  `TALK_TIME` datetime DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL,
  `TASK_ID` varchar(32) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_handtask
-- ----------------------------
INSERT INTO `p_handtask` VALUES ('1', '2015-12-09 10:44:12', '31', '566774f58c831de01597a043', '566512760fd5504c45483a91', '2015-12-10 10:44:30', '3');
INSERT INTO `p_handtask` VALUES ('2', '2015-12-17 11:03:54', '33', '566774f58c831de01597a043', '566512760fd5504c45483a91', '2015-12-11 11:04:08', '2');
INSERT INTO `p_handtask` VALUES ('3', '2015-12-17 11:03:54', '40', '566774f58c831de01597a043', '566512760fd5504c45483a91', '2015-12-12 16:04:08', '1');

-- ----------------------------
-- Table structure for `p_project`
-- ----------------------------
DROP TABLE IF EXISTS `p_project`;
CREATE TABLE `p_project` (
  `id` varchar(32) NOT NULL,
  `PROJECT_NAME` varchar(32) DEFAULT NULL,
  `PROJECT_INTRO` varchar(512) DEFAULT NULL,
  `PROJECT_TYPE_ID` varchar(32) DEFAULT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project
-- ----------------------------
INSERT INTO `p_project` VALUES ('56654bf2709f27ec7219d7ef', '项目项目项目项目一', '项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介项目简介', '56654bf2709f27ec7219d7ee', '5665135f0447a8f04668fd33', '2015-12-07 17:06:53', '1');
INSERT INTO `p_project` VALUES ('566576f22fa833b4064e3fe3', '项目项目项目项目二', 'null', '56654bf2709f27ec7219d7ee', '56654ccbbace76fc6d67073e', '2015-12-07 20:10:11', '1');
INSERT INTO `p_project` VALUES ('5666af69fabc04001f1f9f24', '项目项目005', '驾驶证、身份证都有有效期，为什么结婚证不能有有效期？面对难以抵挡的第四次单身潮和现在与日俱增的离婚率，近日，某学者提出一种大胆而令人惊叹的声音：结婚证应设置7年有效期，到期自动离婚，这样一来，许多社会问题就会迎刃而解。', '5667e4416c6a323c194f97f2', '56654ccbbace76fc6d67073e', '2015-12-08 18:22:34', '1');
INSERT INTO `p_project` VALUES ('5666af73fabc04001f1f9f25', '项目二期201502', '5555111222', '56654bf2709f27ec7219d7ee', '5665135f0447a8f04668fd33', '2015-12-08 18:22:44', '1');
INSERT INTO `p_project` VALUES ('5667d2c33c848ea00185cdcf', '项目项目004', '23123123', '56654bf2709f27ec7219d7ee', '56654ccbbace76fc6d67073e', '2015-12-09 15:05:40', '1');
INSERT INTO `p_project` VALUES ('5667d2d43c848ea00185cdd0', '项目项目003', '1111', '56654bf2709f27ec7219d7ee', '56654ccbbace76fc6d67073e', '2015-12-09 15:05:56', '1');
INSERT INTO `p_project` VALUES ('5667e62cdfe75acc1514ba51', '项目一期201501', '能聊天的美女情感机器人来了!能打乒乓球的机器人可以和你对打!一群机器人在小场地里踢足球……2015世界机器人大会如同“武林大会”,各路厂商带着“小宝贝”纷纷亮相,世界机器人领域大师级的专家学者纷纷登台指点“现在与未来”的智能世界。', '56654bf2709f27ec7219d7ee', '5665135f0447a8f04668fd33', '2015-12-09 16:28:29', '1');
INSERT INTO `p_project` VALUES ('566ec9d9a945957c0eee6b21', '项目项目002', '121213322', '5667e4416c6a323c194f97f2', '56654ccbbace76fc6d67073e', '2015-12-14 21:53:30', '1');

-- ----------------------------
-- Table structure for `p_project_type`
-- ----------------------------
DROP TABLE IF EXISTS `p_project_type`;
CREATE TABLE `p_project_type` (
  `id` varchar(32) NOT NULL,
  `TYPE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_project_type
-- ----------------------------
INSERT INTO `p_project_type` VALUES ('56654bf2709f27ec7219d7ee', '房地产', '2015-12-07 17:06:25', '1');
INSERT INTO `p_project_type` VALUES ('5667e4416c6a323c194f97f2', '其他', '2015-12-09 16:18:02', '1');

-- ----------------------------
-- Table structure for `p_task`
-- ----------------------------
DROP TABLE IF EXISTS `p_task`;
CREATE TABLE `p_task` (
  `id` varchar(32) NOT NULL,
  `TEL_NUM` varchar(255) DEFAULT NULL,
  `TASK_NAME` varchar(32) DEFAULT NULL,
  `TASK_INTRO` varchar(512) DEFAULT NULL,
  `TASK_SUM` int(11) DEFAULT NULL,
  `PROJECT_ID` varchar(32) DEFAULT NULL,
  `TALK_TIMEOUT` int(11) DEFAULT NULL,
  `TALK_TIME_LEN` int(11) DEFAULT NULL COMMENT '有效通话时长',
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of p_task
-- ----------------------------
INSERT INTO `p_task` VALUES ('566774f58c831de01597a043', '13837186852', '任务名称199988', '任务描述1', '1', '5666af69fabc04001f1f9f24', '3600', '40', '2015-12-10 08:25:17', '2015-12-18 08:25:17', '2015-12-09 08:25:25', '1');
INSERT INTO `p_task` VALUES ('566786ddca5012040d6d31a5', '13837186852', '任务名称2121', '任务描述2', '20', '5666af69fabc04001f1f9f24', '3600', '30', '2015-12-12 09:41:22', '2016-01-24 09:41:26', '2015-12-09 09:41:49', '1');
INSERT INTO `p_task` VALUES ('5667d2fc3c848ea00185cdd1', '13837186852', '111', '111', '111', '5666af69fabc04001f1f9f24', '3600', '11', '2015-12-15 15:06:31', '2015-12-23 15:06:31', '2015-12-09 15:06:37', '1');
INSERT INTO `p_task` VALUES ('5667e1f408cac24c16b2c901', '13837186852', '11', '123', '22', '5667d2d43c848ea00185cdd0', '3600', '33', '2015-12-10 16:10:18', '2015-12-11 16:10:18', '2015-12-09 16:10:29', '1');
INSERT INTO `p_task` VALUES ('566a29941007c8380a50e345', '13837186852', 'abc', '33', '11', '5667e62cdfe75acc1514ba51', '3600', '22', '2015-12-11 09:40:30', '2015-12-12 09:40:33', '2015-12-11 09:40:37', '1');
INSERT INTO `p_task` VALUES ('566bd3418fa7fba0182853b5', '13837186852', 'asdf878555', '3123123', '121', '5667e62cdfe75acc1514ba51', '1233333', '123', '2015-12-12 15:56:44', '2015-12-25 15:56:45', '2015-12-12 15:56:49', '1');
INSERT INTO `p_task` VALUES ('566f7d06fe92fb2810655d4b', '13837186852', 'aabb', '123123', '123', '5667d2d43c848ea00185cdd0', '123', '123', '2015-12-17 10:37:52', '2016-04-08 10:37:52', '2015-12-15 10:37:59', '1');
INSERT INTO `p_task` VALUES ('566f8231c5d701ac0a237f5e', '13837186852', '123', '123', '123', '566576f22fa833b4064e3fe3', '123123', '123', '2015-12-03 10:59:56', '2015-12-10 10:59:58', '2015-12-15 11:00:01', '1');
INSERT INTO `p_task` VALUES ('566f83c0c5d701ac0a237f5f', null, 'aa', '123', '123', '5667d2c33c848ea00185cdcf', '123', '123', '2015-12-15 11:06:35', '2015-12-17 11:06:37', '2015-12-15 11:06:41', '1');
INSERT INTO `p_task` VALUES ('566f83e1c953b0440f909165', null, 'bb', '123', '123', '5667d2c33c848ea00185cdcf', '123', '123', '2015-12-15 11:07:09', '2015-12-15 11:07:11', '2015-12-15 11:07:13', '1');
INSERT INTO `p_task` VALUES ('566f84c616f4a7ac134736d8', '123123123', 'cc', '123', '123', '5667d2c33c848ea00185cdcf', '123', '123', '2015-12-17 11:10:56', '2015-12-17 11:10:56', '2015-12-15 11:11:02', '1');
INSERT INTO `p_task` VALUES ('566f86164edd83a4045ee105', '12', 'fsdf', '12121', '1212', '566ec9d9a945957c0eee6b21', '21212', '121', '2015-12-17 11:16:27', '2016-01-29 11:16:27', '2015-12-15 11:16:38', '1');

-- ----------------------------
-- Table structure for `s_auth_code`
-- ----------------------------
DROP TABLE IF EXISTS `s_auth_code`;
CREATE TABLE `s_auth_code` (
  `id` varchar(32) NOT NULL,
  `USER_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_auth_code
-- ----------------------------
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550457', '566512760fd5504c45483a91', '2015-12-08 15:20:16', '1');
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550458', '566512760fd5504c45483a91', '2015-12-08 15:47:03', '1');
INSERT INTO `s_auth_code` VALUES ('5666880a1ac2f8840e550459', '566512760fd5504c45483a92', '2015-12-08 15:47:06', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28a', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28b', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28c', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28d', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28e', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f28f', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f290', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f291', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f292', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566696665640d0040c21f293', '566512760fd5504c45483a91', '2015-12-08 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c44', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c45', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c46', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c47', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c48', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c49', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4a', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4b', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4c', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666970b96050248157e1c4d', '566512760fd5504c45483a92', '2015-12-08 16:38:36', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c4e', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c4f', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c50', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c51', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c52', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c53', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c54', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c55', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c56', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666971a96050248157e1c57', '566512760fd5504c45483a91', '2015-12-08 16:38:51', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7051', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7052', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7053', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7054', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7055', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7056', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7057', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7058', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d7059', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666b090e3ee06d41c6d705a', '566512760fd5504c45483a91', '2015-12-08 18:27:29', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd4', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd5', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd6', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd7', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd8', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecd9', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecda', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdb', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdc', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('5666d3e7b0477e140ac5ecdd', '5666d0c7cca60fe0113d1392', '2015-12-08 20:58:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999277', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999278', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999279', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927a', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927b', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927c', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927d', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927e', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c1399927f', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678ee77bbcbb1c13999280', '5666d061cca60fe0113d1391', '2015-12-09 10:16:07', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999281', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999282', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999283', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999284', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999285', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999286', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999287', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999288', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c13999289', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('56678eef7bbcbb1c1399928a', '5666d061cca60fe0113d1391', '2015-12-09 10:16:15', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc1', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc2', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc3', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc4', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc5', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc6', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc7', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc8', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edc9', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667b2cd34ebf56c17a4edca', '566512760fd5504c45483a92', '2015-12-09 12:49:18', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d3', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d4', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d5', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d6', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d7', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d8', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7d9', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7da', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7db', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('5667e7e6e9f52ef419f5b7dc', '566512760fd5504c45483a91', '2015-12-09 16:35:51', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8c', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8d', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8e', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc8f', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc90', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc91', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc92', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc93', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc94', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ebf46b79bcb241767fc95', '56666155089a64dc10881fd6', '2015-12-14 21:08:23', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c87', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c88', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c89', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8a', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8b', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8c', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8d', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8e', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c8f', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ec0b5fdd7cc4c132b6c90', '56666155089a64dc10881fd6', '2015-12-14 21:14:29', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe656', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe657', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe658', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe659', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65a', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65b', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65c', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65d', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65e', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');
INSERT INTO `s_auth_code` VALUES ('566ece0e6c36612403afe65f', '566512760fd5504c45483a91', '2015-12-14 22:11:26', '1');

-- ----------------------------
-- Table structure for `s_role`
-- ----------------------------
DROP TABLE IF EXISTS `s_role`;
CREATE TABLE `s_role` (
  `id` varchar(32) NOT NULL,
  `ROLE_NAME` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_role
-- ----------------------------
INSERT INTO `s_role` VALUES ('566512760fd5504c45483a93', '超级管理员', '2015-12-01 15:57:22', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace4', '管理员', '2015-12-02 15:57:27', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace5', '信息发布者', '2015-12-03 15:57:31', '1');
INSERT INTO `s_role` VALUES ('566512b49012fb044691ace6', '业务员', '2015-12-04 15:57:36', '1');

-- ----------------------------
-- Table structure for `s_user`
-- ----------------------------
DROP TABLE IF EXISTS `s_user`;
CREATE TABLE `s_user` (
  `id` varchar(32) NOT NULL,
  `ROLE_ID` varchar(32) DEFAULT NULL,
  `USER_NAME` varchar(32) DEFAULT NULL,
  `USER_PASS` varchar(32) DEFAULT NULL,
  `AVATAR_URL` varchar(128) DEFAULT NULL,
  `EMAIL` varchar(64) DEFAULT NULL,
  `MOBILE` varchar(11) DEFAULT NULL,
  `REAL_NAME` varchar(32) DEFAULT NULL,
  `ALIPAY_ACCOUNT` varchar(128) DEFAULT NULL,
  `APIKEY` varchar(64) DEFAULT NULL,
  `SECKEY` varchar(64) DEFAULT NULL,
  `AUTH_CODE_ID` varchar(32) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `STATUS` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of s_user
-- ----------------------------
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a91', '566512b49012fb044691ace6', '18530053050', 'e10adc3949ba59abbe56e057f20f883e', '', '3203317@qq.com', '18530053050', '黄鑫', '3203317@qq.com', '123', '234', '', '2015-09-30 16:33:09', '1');
INSERT INTO `s_user` VALUES ('566512760fd5504c45483a92', '566512b49012fb044691ace6', '13838394480', 'e10adc3949ba59abbe56e057f20f883e', null, '13838394480@qq.com', '13838394480', '吴鹏', '13838394480@qq.com', null, null, '', '2015-09-30 17:33:09', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd32', '566512760fd5504c45483a93', 'bushuo', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '超级管理员', '', null, null, '', '2015-12-07 13:05:02', '1');
INSERT INTO `s_user` VALUES ('5665135f0447a8f04668fd33', '566512b49012fb044691ace5', 'xxfb001', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '信息发布者001', '', null, null, '', '2015-12-07 13:05:42', '1');
INSERT INTO `s_user` VALUES ('56654ccbbace76fc6d67073e', '566512b49012fb044691ace5', 'xxfb002', 'e10adc3949ba59abbe56e057f20f883e', null, '', '', '信息发布者002', '', null, null, '', '2015-12-07 17:10:24', '1');
INSERT INTO `s_user` VALUES ('56666155089a64dc10881fd6', '566512b49012fb044691ace6', '13683800587', 'e10adc3949ba59abbe56e057f20f883e', null, '13683800587@139.com', '13683800587', '假名', '13683800587@139.com', '', '', '5666880a1ac2f8840e550457', '2015-12-08 12:49:26', '1');
INSERT INTO `s_user` VALUES ('5666d061cca60fe0113d1391', '566512b49012fb044691ace6', '13526667995', 'e10adc3949ba59abbe56e057f20f883e', null, '13526667995@qq.com', '13526667995', '郝全', '13526667995@qq.com', '', '', '', '2015-12-08 20:43:13', '1');
INSERT INTO `s_user` VALUES ('5666d0c7cca60fe0113d1392', '566512b49012fb044691ace6', '13137708990', 'e10adc3949ba59abbe56e057f20f883e', null, '13137708990@139.com', '13137708990', '杨光', '13137708990@139.com', '', '', '', '2015-12-08 20:44:56', '1');
